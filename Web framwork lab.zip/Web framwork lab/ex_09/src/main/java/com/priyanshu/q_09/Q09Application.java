package com.priyanshu.q_09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q09Application {

	public static void main(String[] args) {
		SpringApplication.run(Q09Application.class, args);
	}

}
