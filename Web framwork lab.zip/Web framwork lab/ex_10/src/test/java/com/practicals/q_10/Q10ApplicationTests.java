package com.practicals.q_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Q10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
