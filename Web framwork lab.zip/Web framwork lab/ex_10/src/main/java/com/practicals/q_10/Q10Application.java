package com.practicals.q_10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q10Application {

	public static void main(String[] args) {
		SpringApplication.run(Q10Application.class, args);
	}

}
